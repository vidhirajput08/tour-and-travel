// Responsive navbar
document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.getElementById('menu-toggle');
    const navLinks = document.getElementById('nav-links');
    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', function() {
            navLinks.classList.toggle('show');
        });
    }

    // Contact form handler
    const form = document.querySelector('.contact-form');
    const formMessage = document.getElementById('form-message');
    if (form && formMessage) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            formMessage.textContent = "Thank you for your inquiry! We'll contact you soon.";
            form.reset();
        });
    }
});